package com.unt.csce5550.jerin.securepass;

import java.io.IOException;

import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.service.UserService;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ResetPasswordController {
	
	@FXML 
	private TextField userIdField;
	
	@FXML 
	private PasswordField passwordField;
	
	@FXML 
	private PasswordField confirmPasswordField;
	
	@FXML 
	private PasswordField passPhraseField;
	
	@FXML 
	private GridPane attributesGridPane;
	
	@FXML 
	private GridPane newPasswordGridPane;

	
	@FXML 
	private Label passPhraseStatusLabel;
	
	@FXML 
	private Label passwordStatusLabel;

	@FXML 
	private ProgressBar passwordStrengthBar;

	@FXML 
	private Label passwordStrengthLabel;
	
	
	
	@FXML 
	private Button passPhraseSubmitButton;

	@FXML 
	private Button passPhraseBackButton;
	
	@FXML 
	private Button passWordSubmitButton;

	@FXML 
	private Button passWordBackButton;
	
	public void initScreen() {
		newPasswordGridPane.setDisable(true);
		passwordField.setDisable(true);
		confirmPasswordField.setDisable(true);
		passWordSubmitButton.setDisable(true);
		passWordBackButton.setDisable(true);
		
		//FIXME: Testing
		//enableResetPassword();
		
		passwordStrengthBar.progressProperty().bind(passwordField.textProperty().length());
	}
	
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("Login.fxml"));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			//LoginController newSceneController = loader.getController();
			//newSceneController.setLabelText("Jerin");
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void submitPassPhraseClicked() {
		System.out.println("Submit Pass Phrase Button Clicked ");
		if(validatePassPhrase()) {
			String userId = AppUtils.getText(userIdField);
			String passPhrase = AppUtils.getText(passPhraseField);

			User user = UserService.authenticateUserPassPhrase(userId, passPhrase);
			if(user!=null) {
				passPhraseStatusLabel.setText("PassPhrase Validated Successfully!");
				enableResetPassword();
			}else {
				passPhraseStatusLabel.setText("Invalid PassPhrase");
			}
		}

	}
	
	public void enableResetPassword() {
		newPasswordGridPane.setDisable(false);
		passwordField.setDisable(false);
		confirmPasswordField.setDisable(false);
		passWordSubmitButton.setDisable(false);
		passWordBackButton.setDisable(false);
		
		userIdField.setDisable(true);
		passPhraseField.setDisable(true);
		passPhraseSubmitButton.setDisable(true);
		passPhraseBackButton.setDisable(true);

	}
	
	
	public boolean validatePassPhrase() {
		String userId = AppUtils.getText(userIdField);
		String passPhrase = AppUtils.getText(passPhraseField);
		
		
		if(AppUtils.isEmpty(userId)) {
			passPhraseStatusLabel.setText("User ID Name cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(passPhrase)) {
			passPhraseStatusLabel.setText("Pass Phrase cannot be empty");
			return false;
		}
		
		return true;

	}
	
	
	public void submitPasswordClicked() {
		System.out.println("Submit Password Button Clicked ");
		if(validatePassword()) {
			String userId = AppUtils.getText(userIdField);
			String password = AppUtils.getText(passwordField);
			
			User user = UserService.getUser(userId);
			user.setPassword(password);
			
			try {
				UserService.updateUser(user);
				passwordStatusLabel.setText("Password Reset Successfully!");
			
				newPasswordGridPane.setDisable(true);
				passwordField.setDisable(true);
				confirmPasswordField.setDisable(true);
				passWordSubmitButton.setDisable(true);

			} catch (ApplicationException e) {
				passwordStatusLabel.setText("Error resetting password. "+e.getMessage());
				e.printStackTrace();
			}
		}

	}

	public boolean validatePassword() {
		String password = AppUtils.getText(passwordField);
		String confirmPassword = AppUtils.getText(confirmPasswordField);
		
		
		if(AppUtils.isEmpty(password)) {
			passwordStatusLabel.setText("Password cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(confirmPassword)) {
			passwordStatusLabel.setText("Confirm Password cannot be empty");
			return false;
		}

		if(!password.equals(confirmPassword)) {
			passwordStatusLabel.setText("Passwords do not match!");
			return false;
		}
		
		return true;

	}
	
	


}
