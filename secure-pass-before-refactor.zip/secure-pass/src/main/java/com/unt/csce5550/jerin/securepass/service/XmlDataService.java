package com.unt.csce5550.jerin.securepass.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.unt.csce5550.jerin.securepass.model.Attribute;
import com.unt.csce5550.jerin.securepass.model.SecurePass;
import com.unt.csce5550.jerin.securepass.model.Site;
import com.unt.csce5550.jerin.securepass.model.User;


public class XmlDataService {
	

	public static synchronized SecurePass readXML() {
		System.out.println("readXML called ");
		

		SecurePass sp = null;
		try {
			File dataFile = getDataFile();
			
			if(!dataFile.exists()) {
				return new SecurePass();
			}
				
			//checkFileExists(dataFile);
			JAXBContext context = JAXBContext.newInstance(SecurePass.class);
			Unmarshaller marshaller = context.createUnmarshaller();
			Object o = marshaller.unmarshal(dataFile);
			sp = (SecurePass)o;
			System.out.println("Before decryption: "+sp);
			
			sp = EncryptionService.decryptUserPasswords(sp);
			System.out.println("After decryption: "+sp);

		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return sp;
	}
	
	
	public static void writeXML(SecurePass securePass) {
		System.out.println("writeXML called with securePass: "+securePass);
		try {
			securePass = EncryptionService.encryptUserPasswords(securePass);
			File dataFile = getDataFile();
			System.out.println("File Name: "+dataFile.getAbsolutePath());
			JAXBContext context = JAXBContext.newInstance(SecurePass.class);
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			marshaller.marshal(securePass, dataFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static File getDataFile() {
		File outputFile = new File("SecurePass.xml");
		return outputFile;
	}
	
	
	public static void checkFileExists(File f) {
		if(f == null)return;
		System.out.println("File: "+f.getAbsolutePath());
		
		if(!f.exists()) {
			SecurePass sp = new SecurePass();
			sp.addUser(getDummyUser());
			writeXML(sp);
		}
	}
	
	
	private static User getDummyUser() {
		User user = new User();
		user.setUserId("demo");
		user.setPassword("demo");
		user.setPassPhrase("demo");
		user.setFirstName("Demo");
		user.setLastName("User");
		
		List<Site> siteList = getTestSites();
		List<Site> siteListNew = new ArrayList<>();

		for(Site site: siteList) {
			try {
				Site siteNew = EncryptionService.encryptSitePasswords(site, "asdf");
				siteListNew.add(siteNew);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		user.addSites(siteListNew);
		
		return user;
	}
	
	private static List<Site> getTestSites(){
		
		List<Site> siteList = new ArrayList<>();
		siteList.add(new Site("Amazon", "amzUser", "amzPass"));
		siteList.add(new Site("Yahoo", "yahUser", "yahPass"));
		siteList.add(new Site("Gmail", "gmlUser", "gmlPass"));
		siteList.add(new Site("Outlook", "outUser", "outPass"));
		siteList.add(new Site("BOA", "boaUser", "boaPass"));
		return addAttributes(siteList);
		
	}
	
	
	private static List<Site> addAttributes(List<Site> siteList){
		
		for(Site site: siteList) {
			site.getAttributeList().add(new Attribute("ATM PIN", "1122"));
			site.getAttributeList().add(new Attribute("Customer Care No", "888-232-8757"));
			site.getAttributeList().add(new Attribute("Pass Phrase", "Spell it out!"));
		}

		return siteList;
	}
	
}
