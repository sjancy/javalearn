package com.unt.csce5550.jerin.securepass.service;

import java.util.Iterator;

import com.unt.csce5550.jerin.securepass.model.SecurePass;
import com.unt.csce5550.jerin.securepass.model.Site;
import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;

public class SiteService {
	
	public static Site getSite(String userId, String siteId) {
		Integer siteIdInt = new Integer(siteId);
		return getSite(userId, siteIdInt);
	}

	public static Site getSite(String userId, Integer siteId) {
		System.out.println("getSite called with userId: "+userId+"; siteId: "+siteId);
		User user = null;
		SecurePass sp = XmlDataService.readXML();
		for(User u: sp.getUsers()) {
			if(user.getUserId().equalsIgnoreCase(userId) ) {
				user = u;
			}
		}
		if(user == null) {
			return null;
		}
		
		for(Site site: user.getSites()) {
			if(site.getId().equals(siteId)) {
				return site;
			}
		}
		return null;
	}
	
	
	public static boolean updateSite(String userId, Site updatedSite) throws ApplicationException {
		System.out.println("updateSite called with userId: "+userId+"; updatedSite: "+updatedSite);
		User user = null;
		SecurePass sp = XmlDataService.readXML();
		for(User u: sp.getUsers()) {
			if(u.getUserId().equalsIgnoreCase(userId) ) {
				user = u;
			}
		}
		if(user == null) {
			throw new ApplicationException("User not found");
		}
		
		for(Site site: user.getSites()) {
			if(site.getId().equals(updatedSite.getId())) {
				site.copySite(updatedSite);
				XmlDataService.writeXML(sp);
				return true;
			}
		}
		throw new ApplicationException("Site not found");

	}
	
	public static boolean createNewSite(String userId, Site newSite) throws ApplicationException {
		System.out.println("createNewSite called with userId: "+userId+"; newSite: "+newSite);
		User user = null;
		SecurePass sp = XmlDataService.readXML();
		for(User u: sp.getUsers()) {
			if(u.getUserId().equalsIgnoreCase(userId) ) {
				user = u;
			}
		}
		if(user == null) {
			throw new ApplicationException("User not found");
		}
		
		Integer siteID = getNewSiteId(user);
		newSite.setId(siteID);
		user.addSite(newSite);
		
		XmlDataService.writeXML(sp);
		
		return true;
		

	}
	
	
	public static boolean deleteSite(String userId, Site deleteSite) throws ApplicationException {
		System.out.println("deleteSite called with userId: "+userId+"; deleteSite: "+deleteSite);
		User user = null;
		SecurePass sp = XmlDataService.readXML();
		for(User u: sp.getUsers()) {
			if(u.getUserId().equalsIgnoreCase(userId) ) {
				user = u;
			}
		}
		if(user == null) {
			throw new ApplicationException("User not found");
		}
		
		
        Iterator<Site> itr = user.getSites().iterator(); 
        while (itr.hasNext()) 
        { 
        	Site site = itr.next(); 
        	if(site.getId().equals(deleteSite.getId())) {
                itr.remove(); 
				XmlDataService.writeXML(sp);
				return true;
        	}
        } 
		throw new ApplicationException("Site not found");
	}
	
	public static Integer getNewSiteId(User user) {
		
		Integer siteId = 1;
		for(Site site: user.getSites()) {
			if(site.getId().equals(siteId)) {
				siteId++;
			}
		}
		return siteId;
		
	}
	

}
