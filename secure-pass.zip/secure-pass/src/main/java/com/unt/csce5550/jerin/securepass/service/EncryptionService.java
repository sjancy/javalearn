package com.unt.csce5550.jerin.securepass.service;

import javax.crypto.BadPaddingException;

import com.unt.csce5550.jerin.securepass.encryption.AESEncryption;
import com.unt.csce5550.jerin.securepass.encryption.SHA256Hash;
import com.unt.csce5550.jerin.securepass.model.Attribute;
import com.unt.csce5550.jerin.securepass.model.SecurePass;
import com.unt.csce5550.jerin.securepass.model.Site;
import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;

public class EncryptionService {
	
	public static SecurePass encryptUserPasswords(SecurePass sp) throws Exception {
		for(User user: sp.getUsers()) {
			String userId = user.getUserId();
			String userPassword = user.getPassword();
			String userPassPhrase = user.getPassPhrase();
			
			if(!AppUtils.isEmpty(userPassword)) {
				String userPasswordHash = SHA256Hash.getHashStringForUser(userId, userPassword);
				user.setPasswordHash(userPasswordHash);
			}

			if(!AppUtils.isEmpty(userPassPhrase)) {
				String userPassPhraseHash = SHA256Hash.getHashStringForUser(userId, userPassPhrase);
				user.setPassPhraseHash(userPassPhraseHash);
			}
			
		}
		
		return sp;
	}
	
	
	public static SecurePass decryptUserPasswords(SecurePass sp) {
		/*for(User user: sp.getUsers()) {
			
			String userPasswordHash = user.getPasswordHash();
			String userPassPhraseHash = user.getPasswordHash();
		
			
			String encryptedUserPassword = user.getPassword();
			String encryptedUserPassPhrase = user.getPassPhrase();
			String userPassword = null;
			String userPasswordHash = null;
			String userPassPhrase = null;
			try {
				userPassword = AESEncryption.decrypt(encryptedUserPassword, getDefaultKey(), getDefaultSalt());
				userPassPhrase = AESEncryption.decrypt(encryptedUserPassPhrase, getDefaultKey(), getDefaultSalt());
				userPasswordHash = SHA256Hash.getHashString(userPassword);
			} catch (Exception e) {
				user.setPasswordTampered(true);
				e.printStackTrace();
			}
			user.setPassword(userPassword);
			user.setPassPhrase(userPassPhrase);
			
			if(!AppUtils.compareStrings(userPassword, userPasswordHash)) {
				user.setPasswordTampered(true);
			}else {
				user.setPasswordTampered(false);
			}
		
		}*/
		return sp;
	}
	
	
	public static Site encryptSitePasswords(Site site, String key) throws Exception {
		String password = site.getPassword();
		String passwordHash = SHA256Hash.getHashString(password);
		String encryptedPassword = AESEncryption.encrypt(password, key, getDefaultSalt());
		site.setPassword(encryptedPassword);
		site.setPasswordHash(passwordHash);
		
		if(site.getAttributeList()!=null) {
			for(Attribute attr: site.getAttributeList()) {
				String attrValue = attr.getAttributeValue();
				String encryptedValue = AESEncryption.encrypt(attrValue, key, getDefaultSalt());
				attr.setAttributeValue(encryptedValue);
			}
		}
		return site;
	}


	public static Site decryptSitePasswords(Site site, String key) throws ApplicationException {
		String password = site.getPassword();
		String passwordHash = site.getPasswordHash();
		String decryptedPassword = null;
		String decryptedPasswordHash = null;
		try {
			decryptedPassword = AESEncryption.decrypt(password, key, getDefaultSalt());
			decryptedPasswordHash = SHA256Hash.getHashString(decryptedPassword);
			
			if(site.getAttributeList()!=null) {
				for(Attribute attr: site.getAttributeList()) {
					String attrValue = attr.getAttributeValue();
					String decryptedValue = AESEncryption.decrypt(attrValue, key, getDefaultSalt());
					attr.setAttributeValue(decryptedValue);
				}
			}

			
		} catch (BadPaddingException e) {
			site.setPasswordTampered(true);
			e.printStackTrace();
			throw new ApplicationException("Invalid Key");
		}catch (Exception e) {
			site.setPasswordTampered(true);
			e.printStackTrace();
		}
		site.setPassword(decryptedPassword);
		
		//System.out.println("passwordHash: "+passwordHash);
		//System.out.println("decryptedPasswordHash: "+decryptedPasswordHash);
		if(!AppUtils.compareStrings(passwordHash, decryptedPasswordHash)) {
			site.setPasswordTampered(true);
		}else {
			site.setPasswordTampered(false);
		}
		
		return site;
	}
	
	
	private static String getDefaultSalt() {
		String key = "prwxqwexztserxbj";
		return key;
	}

}
