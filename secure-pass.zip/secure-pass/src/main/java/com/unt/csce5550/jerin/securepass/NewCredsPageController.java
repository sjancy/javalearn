package com.unt.csce5550.jerin.securepass;

import static com.unt.csce5550.jerin.securepass.model.SecurePassConstants.LOGIN_PAGE;
import static com.unt.csce5550.jerin.securepass.model.SecurePassConstants.MAIN_PAGE;

import java.io.IOException;

import com.unt.csce5550.jerin.securepass.model.Attribute;
import com.unt.csce5550.jerin.securepass.model.PasswordStrength;
import com.unt.csce5550.jerin.securepass.model.Site;
import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.service.EncryptionService;
import com.unt.csce5550.jerin.securepass.service.SiteService;
import com.unt.csce5550.jerin.securepass.service.UserService;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;

public class NewCredsPageController {
	
	@FXML 
	private Label welcomeLabel;

	@FXML 
	private TextField siteNameTextField;

	@FXML 
	private GridPane attributesGridPane;
	
	@FXML
	private Label statusLabel;
	
	@FXML 
	private ProgressBar passwordStrengthBar;

	@FXML 
	private Label passwordStrengthLabel;
	
	@FXML
	private Button saveButton;
	

	public void setupPasswordEventHandler(PasswordField passwordField) {
		
		passwordField.addEventFilter(KeyEvent.KEY_TYPED, new EventHandler<KeyEvent>() {
		    @Override
		    public void handle(KeyEvent event) {
		    	//System.out.println("KEY_TYPED: "+event.getCharacter());

		    	String pass = passwordField.getText();
		    	//System.out.println("pass: "+pass);

		    	if (!(event.getCode().equals(KeyCode.BACK_SPACE) || event.getCode().equals(KeyCode.DELETE))){
		        	pass = pass + event.getCharacter();
		        }
		        
		        
		    	PasswordStrength passwordStrength = AppUtils.checkPasswordStrength(pass);
		    	//System.out.println("passwordStrength: "+passwordStrength);
		    	
		    	if(AppUtils.isEmpty(pass)) {
					passwordStrengthBar.setProgress(0);
					passwordStrengthLabel.setText("");
					return;
		    		
		    	}
		    	
		    	switch(passwordStrength) {
		    	case WEAK:
			    	//System.out.println("Setting .33");
					passwordStrengthBar.setProgress(.33);
					passwordStrengthLabel.setText("Password Strength: Weak");
					passwordStrengthLabel.setStyle("-fx-text-fill: red;");
		    		break;
		    	case MEDIUM:
			    	//System.out.println("Setting .66");
			    	passwordStrengthBar.setProgress(.66);
					passwordStrengthLabel.setText("Password Strength: Medium");
					passwordStrengthLabel.setStyle("-fx-text-fill: orange;");
		    		break;
		    	case STRONG:
			    	//System.out.println("Setting 1");
					passwordStrengthBar.setProgress(1);
					passwordStrengthLabel.setText("Password Strength: Strong");
					passwordStrengthLabel.setStyle("-fx-text-fill: green;");
		    		break;
		    	}
				
		    	
		                          
		    }});
	}
	
	
	public void populateScreen() {
		//System.out.println("NewCredsPageController: populateScreen called.  site: ");
		
		User user = UserService.getUser(LoginController.getCurrentUser().getUserId());
		welcomeLabel.setText("Welcome "+user.getFirstName()+" "+user.getLastName());
		

		//siteNameLabel.setText(site.getSite());
		
	    Label userLabel = new Label("User ID");
	    TextField userId = new TextField();
	    
	    Label passLabel = new Label("Password");
	    PasswordField pass = new PasswordField();
	    setupPasswordEventHandler(pass);
	    
	    Insets labelInset = new Insets(5,0,0,10); // top 5 and left 10 padding
	    userLabel.setPadding(labelInset);
	    userId.setPadding(labelInset);
	    passLabel.setPadding(labelInset);
	    pass.setPadding(labelInset);
	    
	    
	    RowConstraints r = new RowConstraints(30);
	    attributesGridPane.getRowConstraints().add(r);
	    //attributesGridPane.setGridLinesVisible(false);
	    
	    //Rownum 0 is header
	    
	    //Rownum 1
	    int rowNum = 1;
	    attributesGridPane.add(userLabel, 0, rowNum,1,1);
	    attributesGridPane.add(userId, 1, rowNum,1,1);
	    rowNum++;
	    
	    //Rownum 2
	    attributesGridPane.add(passLabel, 0, rowNum,1,1);
	    attributesGridPane.add(pass, 1, rowNum,1,1);
	    rowNum++;
	    
		for(;rowNum<13;rowNum++) {
			TextField attrNameTF = new TextField();
		    attrNameTF.setPadding(labelInset);
		    TextField attrValueTF = new TextField();
		    attrValueTF.setPadding(labelInset);
		
		    attributesGridPane.add(attrNameTF, 0, rowNum);
		    attributesGridPane.add(attrValueTF, 1, rowNum);
		}
		
	}
	
	public void goBackButtonClicked(ActionEvent event) {
		//System.out.println("Go Back Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource(MAIN_PAGE));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			MainPageContoller newSceneController = loader.getController();
			User user = UserService.getUser(LoginController.getCurrentUser().getUserId());
			newSceneController.initializePage(user);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void saveButtonClicked(ActionEvent event) {
		//System.out.println("Save Button Clicked ");
		Node[][] gridNodes = gridPaneNodesAsArray();
		
		Site site = new Site();
		
		//Row 0 is header
		
		//Row 1 is User
		TextField userIdTextField = (TextField)gridNodes[1][1];
		String userId = (userIdTextField!=null)?userIdTextField.getText():null;
		
		//Row 1 is Password
		TextField passwdTextField = (TextField)gridNodes[1][2];
		String password = (passwdTextField!=null)?passwdTextField.getText():null;
		
		
		//System.out.println("User ID: "+userId);
		//System.out.println("Password: "+password);
		
		site.setSite(siteNameTextField.getText());
		site.setUserId(userId);
		site.setPassword(password);
		
		//Validate
		if(AppUtils.isEmpty(siteNameTextField.getText())) {
			statusLabel.setText("Site Name cannot be empty");
			statusLabel.setStyle("-fx-text-fill: red;");
			return;
		}
		if(AppUtils.isEmpty(userId)) {
			statusLabel.setText("User ID cannot be empty");
			statusLabel.setStyle("-fx-text-fill: red;");
			return;
		}
		if(AppUtils.isEmpty(password)) {
			statusLabel.setText("Password cannot be empty");
			statusLabel.setStyle("-fx-text-fill: red;");
			return;
		}
		
		//System.out.println("Length: "+gridNodes[0].length);
		
		for(int i=3; i<gridNodes[0].length; i++) {
			if(!( gridNodes[0][i] instanceof TextField)) {
				continue;
			}
			TextField attrName = (TextField)gridNodes[0][i];
			TextField attrValue = (TextField)gridNodes[1][i];
			
			
			if(!isEmpty(attrName) && !isEmpty(attrValue) ) {
				//System.out.println(i+": "+attrName.getText()+" - "+attrValue.getText());
				Attribute attr = new Attribute(attrName.getText(), attrValue.getText());
				site.addAttribute(attr);
			}
		}
		//System.out.println("New Site: "+site);
        
		String encryptionKey = EncryptionKeyConfirmBox.confirm("Encryption Key", "Enter the encryption key");
        //System.out.println("encryptionKey: "+encryptionKey);
        if(AppUtils.isEmpty(encryptionKey)) {
       	 	return;
        }
		try {
	        site = EncryptionService.encryptSitePasswords(site, encryptionKey);
			User currentUser = LoginController.getCurrentUser();

			SiteService.createNewSite(currentUser.getUserId(), site);
		} catch (Exception e) {
			statusLabel.setText("Error Creating New Site: "+e.getMessage());
			statusLabel.setStyle("-fx-text-fill: red;");
			e.printStackTrace();
			return;
		}
		
		statusLabel.setText("Site Saved Successfully!");
		statusLabel.setStyle("-fx-text-fill: green;");
		disableAllFields();
	}
	
	public void disableAllFields() {
		siteNameTextField.setDisable(true);
		for(Node child: attributesGridPane.getChildren()) {
			child.setDisable(true);
		}
		
	}
	
	
	
	public static boolean isEmpty(TextField tf) {
		
		if(tf!=null && !isEmpty(tf.getText())) {
			return false;
		}
		return true;
	}
	
	public static boolean isEmpty(String str) {
		if(str!=null && str.trim().length()>0) {
			return false;
		}
		return true;
	}
	
	public Node[][] gridPaneNodesAsArray() {
		
		Node [][] gridPaneNodes = new Node[3][15] ;
		
		for (Node child : attributesGridPane.getChildren()) {
		    Integer column = GridPane.getColumnIndex(child);
		    Integer row = GridPane.getRowIndex(child);
		    if (column != null && row != null) {
				//System.out.println(column+" - "+row+" - "+child);
		        gridPaneNodes[column][row] = child ;
		    }
		}
		
		return gridPaneNodes;
		
	}
	
	public void logOutButtonClicked(ActionEvent event) {
		//System.out.println("Log Out Button Clicked ");
		
		try {
			Parent newViewParent = FXMLLoader.load(getClass().getResource(LOGIN_PAGE));
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	




}
