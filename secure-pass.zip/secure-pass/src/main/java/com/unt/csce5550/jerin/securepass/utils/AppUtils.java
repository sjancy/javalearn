package com.unt.csce5550.jerin.securepass.utils;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.unt.csce5550.jerin.securepass.model.PasswordStrength;

import javafx.scene.control.TextField;

public class AppUtils {
	public static boolean isEmpty(TextField tf) {
		
		if(tf!=null && !isEmpty(tf.getText())) {
			return false;
		}
		return true;
	}
	
	public static boolean isEmpty(String str) {
		if(str!=null && str.trim().length()>0) {
			return false;
		}
		return true;
	}
	
	public static String getText(TextField tf) {
		
		if(!isEmpty(tf)) {
			return tf.getText();
		}else {
			return null;
		}
		
	}
	
	
	public static boolean containsSpecialCharacter(String s) {
		Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(s);
		boolean b = m.find();
		return b;
	}
	
	public static PasswordStrength checkPasswordStrength(String password) {

		boolean hasLetter = false;
		boolean hasDigit = false;
		boolean hasSpecialChar = false;

		PasswordStrength passwordStrength = PasswordStrength.WEAK;

		for (int i = 0; i < password.length(); i++) {
			char x = password.charAt(i);
			if (hasLetter || Character.isLetter(x)) {
				//System.out.println("hasLetter: "+x );
				hasLetter = true;
			}

			if (hasDigit || Character.isDigit(x)) {
				//System.out.println("hasDigit: "+x );
				hasDigit = true;
			}

			if (hasSpecialChar || AppUtils.containsSpecialCharacter(x + "")) {
				//System.out.println("hasSpecialChar: "+x );
				hasSpecialChar = true;
			}

			if (hasLetter && hasDigit && hasSpecialChar) {
				//System.out.println("STRONG: "+x );
				passwordStrength = PasswordStrength.STRONG;
			}

		}

		if (passwordStrength!= PasswordStrength.STRONG && ((hasLetter && hasDigit) || (hasLetter && hasSpecialChar) || (hasDigit && hasSpecialChar))) {
			//System.out.println("MEDIUM: " );
			passwordStrength = PasswordStrength.MEDIUM;
		}

		if (password.length() < 8) {
			//System.out.println("length < 8" );
			if (passwordStrength == PasswordStrength.STRONG) {
				passwordStrength = PasswordStrength.MEDIUM;
			} else if (passwordStrength == PasswordStrength.MEDIUM) {
				passwordStrength = PasswordStrength.WEAK;
			}
		}

		return passwordStrength;
	}
	
	
	public static long getDateDiffInMinutes(Date d1, Date d2) {
		if(d1==null || d2==null) {
			return 0;
		}
		
		long diffInMilliSecs = d2.getTime() - d1.getTime();
		long diffInMinutes   = diffInMilliSecs / (60 * 1000) % 60; 
		
		return diffInMinutes;
		

	}
	
	
	public static boolean compareStrings(String s1, String s2) {
		if(s1!=null && s1!=null && s1.equals(s2)) {
			return true;
		}
		return false;
	}

}
