package com.unt.csce5550.jerin.securepass;

import java.io.IOException;

import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.service.UserService;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;
import static com.unt.csce5550.jerin.securepass.model.SecurePassConstants.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {
	
	@FXML 
	private TextField userIdTf;

	@FXML 
	private PasswordField passwordPf;

	@FXML 
	private Label statusLabel;
	
	private static User currentUser;
	
	public static User getCurrentUser() {
		return currentUser;
	}
	
	public void loginButtonClicked(ActionEvent event) {
		//System.out.println("User Logged In");
		
		if(!validate()) {
			return;
		}
		
		String userId = userIdTf.getText();
		User user = null;
		String errorMessage = "";
		try {
			user = UserService.authenticateUser(userId, passwordPf.getText());
		} catch (ApplicationException e1) {
			errorMessage = e1.getMessage();
			//System.out.println("Exception thrown during authentication.  "+errorMessage);
		}
		
		//System.out.println("authStatus: "+user);
		
		try {
			if(user == null) {
				statusLabel.setText(errorMessage);
				passwordPf.setText("");
				statusLabel.setStyle("-fx-text-fill: red;");
				return;
			}
			currentUser = user;
		
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource(MAIN_PAGE));
			Parent newViewParent = loader.load();
			
			
			Scene newScene = new Scene(newViewParent);
			
			MainPageContoller newSceneController = loader.getController();
			newSceneController.initializePage(user);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			statusLabel.setText(e.getMessage());
			statusLabel.setStyle("-fx-text-fill: red;");
			e.printStackTrace();
		}
		
	}
	
	public boolean validate() {
		String userId = AppUtils.getText(userIdTf);
		String password = AppUtils.getText(passwordPf);
		
		
		if(AppUtils.isEmpty(userId)) {
			statusLabel.setText("User ID cannot be empty");
			statusLabel.setStyle("-fx-text-fill: red;");
			return false;
		}
		if(AppUtils.isEmpty(password)) {
			statusLabel.setText("Password cannot be empty");
			statusLabel.setStyle("-fx-text-fill: red;");
			return false;
		}

		
		return true;
	}
	
	public void resetButtonClicked() {
		//System.out.println("Reset Button Clicked");
		userIdTf.setText("");
		passwordPf.setText("");

	}
	
	
	public void newUserLinkClicked(ActionEvent event) {
		//System.out.println("New User Link Clicked");
		
		try {
			Parent newViewParent = FXMLLoader.load(getClass().getResource(NEW_USER_PAGE));
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
	public void forgotPasswordLinkClicked(ActionEvent event) {
		//System.out.println("Forgot Password Link Clicked");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource(RESET_PASSWORD_PAGE));
			Parent newViewParent = loader.load();

			Scene newScene = new Scene(newViewParent);
			ResetPasswordController newSceneController = loader.getController();
			newSceneController.initScreen();
			

			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
}
