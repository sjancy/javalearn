package com.unt.csce5550.jerin.securepass;

import java.io.IOException;
import java.util.Iterator;

import com.unt.csce5550.jerin.securepass.model.Site;
import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.service.EncryptionService;
import com.unt.csce5550.jerin.securepass.service.SiteService;
import com.unt.csce5550.jerin.securepass.service.UserService;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;
import static com.unt.csce5550.jerin.securepass.model.SecurePassConstants.*;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image ;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;


public class MainPageContoller {
	
	@FXML 
	private Label welcomeLabel;
	
	@FXML 
	private Label testLabel;
	
	@FXML 
	private GridPane gridPane;
	
	@FXML
	private Label statusLabel;



	
	public void initializePage(User user) {
		System.out.println("initializePage called with user: "+user);
		welcomeLabel.setText("Welcome "+user.getFirstName()+" "+user.getLastName());
		
	    int rowNum = 1;
	    for(Site site: user.getSites()) {
		    Label siteLabel = new Label(site.getSite());
		    Label userId = new Label(site.getUserId());
		    Label pass = new Label("******"); //new Label(c.getPassword());
		    
		    Insets labelInset = new Insets(5,0,0,10); //Only top 5 and left 10 padding
		    siteLabel.setPadding(labelInset);
		    userId.setPadding(labelInset);
		    pass.setPadding(labelInset);
		    
		    
		    
		    RowConstraints r = new RowConstraints(30);
		    gridPane.getRowConstraints().add(r);
		    
		    gridPane.add(siteLabel, 0, rowNum);
		    gridPane.add(userId, 1, rowNum);
		    gridPane.add(pass, 2, rowNum);
		    
		    int imageWidth = 20;
		    int imageHeight = 20;
		    
		    
		    HBox hbox = new HBox();
		    Insets inset = new Insets(5,0,0,10); //Only top 5 and left 10 padding
			hbox.setPadding(inset);
			hbox.setSpacing(10);
			
			
			Image image = new Image("images/view.png");
		    ImageView imageView = new ImageView(image);
		    imageView.setFitWidth(imageWidth);
		    imageView.setFitHeight(imageHeight);
			Button button = new Button("", imageView);
			button.setPadding(Insets.EMPTY);
			button.setOnAction(getViewButtonEventHandler());
			button.setTooltip(new Tooltip("View"));
			button.setUserData(site);
			
		    hbox.getChildren().add(button);

			
		    
		    Image editImage = new Image("images/edit.png");
		    ImageView editImageView = new ImageView(editImage);
		    editImageView.setFitWidth(imageWidth);
		    editImageView.setFitHeight(imageHeight);
			Button editButton = new Button("", editImageView);
			editButton.setPadding(Insets.EMPTY);
			editButton.setOnAction(getModifyButtonEventHandler());
			editButton.setTooltip(new Tooltip("Edit"));
			editButton.setUserData(site);
		    hbox.getChildren().add(editButton);
		    

		    Image deleteImage = new Image("images/delete-3.png");
		    ImageView deleteImageView = new ImageView(deleteImage);
		    deleteImageView.setFitWidth(imageWidth);
		    deleteImageView.setFitHeight(imageHeight);
			Button deleteButton = new Button("", deleteImageView);
			deleteButton.setPadding(Insets.EMPTY);
			deleteButton.setOnAction(getDeleteButtonEventHandler());
			deleteButton.setTooltip(new Tooltip("Delete"));
			deleteButton.setUserData(site);
		    hbox.getChildren().add(deleteButton);

		    
		    hbox.getChildren().add(deleteImageView);

		    gridPane.add(hbox, 3, rowNum);

		    rowNum++;
	    }
	    
	}
	
	
	private EventHandler<ActionEvent> getViewButtonEventHandler() {
		
		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

		     @Override
		     public void handle(ActionEvent event) {
		         System.out.println("View button pressed "+event);
		         
		         String encryptionKey = EncryptionKeyBox.confirm("Encryption Key", "Enter the encryption key");
		         
		         System.out.println("encryptionKey: "+encryptionKey);
		         if(AppUtils.isEmpty(encryptionKey)) {
		        	 return;
		         }
		         
		         System.out.println("Source: "+event.getSource());
		         Object obj = event.getSource();
		         Object userData =  ((Button) obj).getUserData() ;
		         Site site = (Site)userData;
		         
		         try {
					site = EncryptionService.decryptSitePasswords(site, encryptionKey);
				} catch (ApplicationException e1) {
					statusLabel.setText("Invalid Encryption Key");
					statusLabel.setStyle("-fx-text-fill: red;");
					e1.printStackTrace();
					return;
				}
		         
		         System.out.println( ((Button) obj).getUserData() );
		         
		         

		         //event.consume();
		         System.out.println("After Consume pressed ");

		 		try {
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource(VIEW_SITE_PAGE));
					Parent newViewParent = loader.load();
					
					Scene newScene = new Scene(newViewParent);
					ViewCredsPageController newSceneController = loader.getController();
					newSceneController.populateScreen(site);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}
	
	
	private EventHandler<ActionEvent> getModifyButtonEventHandler() {
		
		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

		     @Override
		     public void handle(ActionEvent event) {
		         System.out.println("Modify button pressed "+event);

		         System.out.println("Source: "+event.getSource());
		         Object obj = event.getSource();
		         Object userData =  ((Button) obj).getUserData() ;
		         Site site = (Site)userData;
		         
		         
		         String encryptionKey = EncryptionKeyBox.confirm("Encryption Key", "Enter the encryption key");
		         
		         System.out.println("encryptionKey: "+encryptionKey);
		         if(AppUtils.isEmpty(encryptionKey)) {
		        	 return;
		         }
		         
		         try {
					site = EncryptionService.decryptSitePasswords(site, encryptionKey);
				} catch (ApplicationException e1) {
					statusLabel.setText("Invalid Encryption Key");
					statusLabel.setStyle("-fx-text-fill: red;");
					e1.printStackTrace();
					return;
				}


		         //event.consume();
		         System.out.println("After Consume pressed ");

		 		try {
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource(MODIFY_SITE_PAGE));
					Parent newViewParent = loader.load();
					
					Scene newScene = new Scene(newViewParent);
					ModifyCredsPageController newSceneController = loader.getController();
					newSceneController.populateScreen(site, encryptionKey);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}
	
	
	private EventHandler<ActionEvent> getDeleteButtonEventHandler() {

		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				System.out.println("Delete button pressed " + event);
				System.out.println("Source: " + event.getSource());
				boolean confirmStatus = ConfirmationBox.confirm("Delete Confirm", "Are you sure?");
				if(!confirmStatus) {
					return;
				}
				Object obj = event.getSource();
				Object userData = ((Button) obj).getUserData();
				Site site = (Site) userData;

				try {
					String currentUserId = LoginController.getCurrentUser().getUserId();
					SiteService.deleteSite(currentUserId, site);
				} catch (ApplicationException e) {
					e.printStackTrace();
					statusLabel.setText("Delete Site Failed: "+e.getMessage());
					statusLabel.setStyle("-fx-text-fill: red;");
					return;
				}
				
				//clearGridPane();
				
				reloadPage(event);
				//initializePage(LoginController.getCurrentUser());
			}
		};

		return ev;

	}
	
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			Parent newViewParent = FXMLLoader.load(getClass().getResource(LOGIN_PAGE));
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void clearGridPane() {
		
		
		Iterator<Node> iterator = gridPane.getChildren().iterator();
		while(iterator.hasNext()) {
			Node child = iterator.next();
		    Integer column = GridPane.getColumnIndex(child);
		    Integer row = GridPane.getRowIndex(child);
		    
		    if(row!=null && row==0) {
		    	continue;
		    }
		    
		    if (column != null && row != null) {
				System.out.println(column+" - "+row+" - "+child);
				iterator.remove();
		    }
		}
	}

	
	
	public void newSiteButtonClicked(ActionEvent event) {
		System.out.println("New Site Back Button Clicked ");
		
 		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource(NEW_SITE_PAGE));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			NewCredsPageController newSceneController = loader.getController();
			newSceneController.populateScreen();
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void reloadPage(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource(MAIN_PAGE));
			Parent newViewParent = loader.load();
			
			
			Scene newScene = new Scene(newViewParent);

			User currentUser = LoginController.getCurrentUser();
			currentUser = UserService.getUser(currentUser.getUserId());

			MainPageContoller newSceneController = loader.getController();
			newSceneController.initializePage(currentUser);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void generatePasswordClicked(ActionEvent event) {
		System.out.println("generatePasswordClicked Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource(GENERATE_PASSWORD_PAGE));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
}
