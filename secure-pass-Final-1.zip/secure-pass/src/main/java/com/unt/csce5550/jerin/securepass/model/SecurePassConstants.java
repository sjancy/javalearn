package com.unt.csce5550.jerin.securepass.model;

public class SecurePassConstants {
	
	public static final String FXML_PATH = "/fxml/";
	public static final String CSS_PATH = "/css/";
	
	public static final String LOGIN_PAGE             = FXML_PATH+"Login.fxml";
	public static final String MAIN_PAGE              = FXML_PATH+"MainPage.fxml";
	public static final String NEW_SITE_PAGE          = FXML_PATH+"NewCredsPage.fxml";
	public static final String VIEW_SITE_PAGE         = FXML_PATH+"ViewCredsPage.fxml";
	public static final String MODIFY_SITE_PAGE       = FXML_PATH+"ModifyCredsPage.fxml";
	public static final String GENERATE_PASSWORD_PAGE = FXML_PATH+"GeneratePasswordPage.fxml";
	public static final String RESET_PASSWORD_PAGE    = FXML_PATH+"ResetPasswordPage.fxml";
	public static final String NEW_USER_PAGE          = FXML_PATH+"NewUserPage.fxml";

	public static final String CSS_FILE               = CSS_PATH+"bootstrap3.css";
}
