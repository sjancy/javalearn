package com.unt.csce5550.jerin.securepass;

import com.unt.csce5550.jerin.securepass.utils.AppUtils;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EncryptionKeyBox {
	
	static String encryptionKey = "";
	
	public static String confirm(String title, String message) {
		encryptionKey = "";
		Stage window = new Stage();
		
		
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(250);
		
		Label label = new Label();
		label.setText(message);
		
		Label statusLabel = new Label();
		PasswordField encryptionKeyField = new PasswordField();
	    Insets labelInset = new Insets(5,10,5,10); //Only top 5 and left 10 padding
		encryptionKeyField.setPadding(labelInset);
		
		
		
		Button submitButton = new Button("Submit");
		submitButton.setOnAction(e -> {
			encryptionKey = encryptionKeyField.getText();
			if(AppUtils.isEmpty(encryptionKey)){
				statusLabel.setText("Encryption Key cannot be empty");
				return;
			}
			window.close();	
		});
		
		
		VBox vBox = new VBox(10);
		vBox.getChildren().addAll(label, encryptionKeyField,  submitButton, statusLabel);
		VBox.setMargin(encryptionKeyField, labelInset);
		vBox.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(vBox);
		window.setScene(scene);
		window.showAndWait();
		
		return encryptionKey;
		
	}

}
