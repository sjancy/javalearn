package com.unt.csce5550.jerin.securepass;

import java.io.IOException;

import com.unt.csce5550.jerin.securepass.model.PasswordStrength;
import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.service.UserService;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;
import static com.unt.csce5550.jerin.securepass.model.SecurePassConstants.*;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ResetPasswordController {
	
	@FXML 
	private TextField userIdField;
	
	@FXML 
	private PasswordField passwordField;
	
	@FXML 
	private PasswordField confirmPasswordField;
	
	@FXML 
	private PasswordField passPhraseField;
	
	@FXML 
	private GridPane attributesGridPane;
	
	@FXML 
	private GridPane newPasswordGridPane;

	
	@FXML 
	private Label passPhraseStatusLabel;
	
	@FXML 
	private Label passwordStatusLabel;

	@FXML 
	private ProgressBar passwordStrengthBar;

	@FXML 
	private Label passwordStrengthLabel;
	
	
	
	@FXML 
	private Button passPhraseSubmitButton;

	@FXML 
	private Button passPhraseBackButton;
	
	@FXML 
	private Button passWordSubmitButton;

	@FXML 
	private Button passWordBackButton;
	
	public void initScreen() {
		newPasswordGridPane.setDisable(true);
		passwordField.setDisable(true);
		confirmPasswordField.setDisable(true);
		passWordSubmitButton.setDisable(true);
		passWordBackButton.setDisable(true);
		
		
	    setupPasswordEventHandler(passwordField);
	}
	
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource(LOGIN_PAGE));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void submitPassPhraseClicked() {
		System.out.println("Submit Pass Phrase Button Clicked ");
		if(validatePassPhrase()) {
			String userId = AppUtils.getText(userIdField);
			String passPhrase = AppUtils.getText(passPhraseField);

			User user = UserService.authenticateUserPassPhrase(userId, passPhrase);
			if(user!=null) {
				passPhraseStatusLabel.setText("PassPhrase Validated Successfully!");
				passPhraseStatusLabel.setStyle("-fx-text-fill: green;");
				enableResetPassword();
			}else {
				passPhraseStatusLabel.setText("Invalid PassPhrase");
				passPhraseStatusLabel.setStyle("-fx-text-fill: red;");
			}
		}

	}
	
	public void enableResetPassword() {
		newPasswordGridPane.setDisable(false);
		passwordField.setDisable(false);
		confirmPasswordField.setDisable(false);
		passWordSubmitButton.setDisable(false);
		passWordBackButton.setDisable(false);
		
		userIdField.setDisable(true);
		passPhraseField.setDisable(true);
		passPhraseSubmitButton.setDisable(true);
		passPhraseBackButton.setDisable(true);

	}
	
	
	public boolean validatePassPhrase() {
		String userId = AppUtils.getText(userIdField);
		String passPhrase = AppUtils.getText(passPhraseField);
		
		
		if(AppUtils.isEmpty(userId)) {
			passPhraseStatusLabel.setText("User ID Name cannot be empty");
			passPhraseStatusLabel.setStyle("-fx-text-fill: red;");
			return false;
		}
		if(AppUtils.isEmpty(passPhrase)) {
			passPhraseStatusLabel.setText("Pass Phrase cannot be empty");
			passPhraseStatusLabel.setStyle("-fx-text-fill: red;");
			return false;
		}
		
		return true;

	}
	
	
	public void submitPasswordClicked() {
		System.out.println("Submit Password Button Clicked ");
		if(validatePassword()) {
			String userId = AppUtils.getText(userIdField);
			String password = AppUtils.getText(passwordField);
			
			User user = UserService.getUser(userId);
			user.setPassword(password);
			
			try {
				UserService.updateUser(user);
				passwordStatusLabel.setText("Password Reset Successfully!");
				passwordStatusLabel.setStyle("-fx-text-fill: green;");
			
				newPasswordGridPane.setDisable(true);
				passwordField.setDisable(true);
				confirmPasswordField.setDisable(true);
				passWordSubmitButton.setDisable(true);

			} catch (ApplicationException e) {
				passwordStatusLabel.setText("Error resetting password. "+e.getMessage());
				passwordStatusLabel.setStyle("-fx-text-fill: red;");
				e.printStackTrace();
			}
		}

	}

	public boolean validatePassword() {
		String password = AppUtils.getText(passwordField);
		String confirmPassword = AppUtils.getText(confirmPasswordField);
		
		
		if(AppUtils.isEmpty(password)) {
			passwordStatusLabel.setText("Password cannot be empty");
			passwordStatusLabel.setStyle("-fx-text-fill: red;");
			return false;
		}
		if(AppUtils.isEmpty(confirmPassword)) {
			passwordStatusLabel.setText("Confirm Password cannot be empty");
			passwordStatusLabel.setStyle("-fx-text-fill: red;");
			return false;
		}

		if(!password.equals(confirmPassword)) {
			passwordStatusLabel.setText("Passwords do not match!");
			passwordStatusLabel.setStyle("-fx-text-fill: red;");
			return false;
		}
		
		return true;

	}
	
	
	public void setupPasswordEventHandler(TextField passwordField) {
		
		passwordField.addEventFilter(KeyEvent.KEY_TYPED, new EventHandler<KeyEvent>() {
		    @Override
		    public void handle(KeyEvent event) {
		    	System.out.println("KEY_TYPED: "+event.getCharacter());

		    	String pass = passwordField.getText();
		    	System.out.println("pass: "+pass);

		    	if (!(event.getCode().equals(KeyCode.BACK_SPACE) || event.getCode().equals(KeyCode.DELETE))){
		        	pass = pass + event.getCharacter();
		        }
		        
		        
		    	setPasswordStrengthProgressBar(pass);
				
		    	
		                          
		    }});
	}
	
	
	public void setPasswordStrengthProgressBar(String pass) {
		
		if(AppUtils.isEmpty(pass))return;
		
    	PasswordStrength passwordStrength = AppUtils.checkPasswordStrength(pass);
    	System.out.println("passwordStrength: "+passwordStrength);
    	
    	if(AppUtils.isEmpty(pass)) {
			passwordStrengthBar.setProgress(0);
			passwordStrengthLabel.setText("");
			return;
    		
    	}
    	
    	switch(passwordStrength) {
    	case WEAK:
	    	System.out.println("Setting .33");
			passwordStrengthBar.setProgress(.33);
			passwordStrengthLabel.setText("Password Strength: Weak");
    		break;
    	case MEDIUM:
	    	System.out.println("Setting .66");
	    	passwordStrengthBar.setProgress(.66);
			passwordStrengthLabel.setText("Password Strength: Medium");
    		break;
    	case STRONG:
	    	System.out.println("Setting 1");
			passwordStrengthBar.setProgress(1);
			passwordStrengthLabel.setText("Password Strength: Strong");
    		break;
    	}
	}
	
	


}
