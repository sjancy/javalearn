package com.unt.csce5550.jerin.securepass.encryption;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
 
public class AESEncryption {
 
	public static String SECRET_KEY_FACTORY_ALGORITHM = "PBKDF2WithHmacSHA256"; //Reference: https://docs.oracle.com/javase/8/docs/technotes/guides/security/StandardNames.html#SecretKeyFactory
	public static String AES_ALGORITHM                = "AES";      // Algorithm Used
	public static String CIPHER_TRANSFORMATION        = "AES/CBC/PKCS5Padding";  //AES Algorithm, with Cipher Block Chaining (CBC) 
	
	public static int ITERATION_COUNT = 1500;   // Iteration count 
	public static int KEY_LENTH       = 256;     //AES Key Length (AES-265)

	
    private static byte[] initializationVector = new byte[16];
    private static IvParameterSpec ivParameterSpec = new IvParameterSpec(initializationVector);

 
    public static String encrypt(String stringToEncrypt, String encryptionKey, String salt)  throws Exception
    {
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
        KeySpec keySpec = new PBEKeySpec(encryptionKey.toCharArray(), salt.getBytes(), ITERATION_COUNT, KEY_LENTH);

        SecretKey generatedSecretKey = secretKeyFactory.generateSecret(keySpec);
        SecretKeySpec secretKeySpec = new SecretKeySpec(generatedSecretKey.getEncoded(), AES_ALGORITHM);
         
        Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
        return Base64.getEncoder().encodeToString(cipher.doFinal(stringToEncrypt.getBytes("UTF-8")));
    }
 
    public static String decrypt(String stringToDecrypt, String encryptionKey, String salt) throws IllegalBlockSizeException, BadPaddingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException 
    {
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
        KeySpec keySpec = new PBEKeySpec(encryptionKey.toCharArray(), salt.getBytes(), ITERATION_COUNT, KEY_LENTH);

        SecretKey generatedSecretKey = secretKeyFactory.generateSecret(keySpec);
        SecretKeySpec secretKeySpec = new SecretKeySpec(generatedSecretKey.getEncoded(), AES_ALGORITHM);
         
        Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(Base64.getDecoder().decode(stringToDecrypt)));
    }
    
    public static void main(String[] args) 
    {
        String encryptionKey = "Jerin";
        String salt = "asdf";
         
        String originalString = "String to encrypt";
        String encryptedString = "";
        String decryptedString = "";
		try {
			encryptedString = AESEncryption.encrypt(originalString, encryptionKey, salt);
			decryptedString = AESEncryption.decrypt(encryptedString, encryptionKey, salt) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
         
        System.out.println(originalString);
        System.out.println(encryptedString);
        System.out.println(decryptedString);
    }
}