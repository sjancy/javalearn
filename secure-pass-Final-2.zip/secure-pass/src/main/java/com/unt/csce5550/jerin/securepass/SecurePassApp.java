package com.unt.csce5550.jerin.securepass;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;

import static com.unt.csce5550.jerin.securepass.model.SecurePassConstants.*;


public class SecurePassApp extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource(LOGIN_PAGE));
			Scene scene = new Scene(root,600,700);
			scene.getStylesheets().add(getClass().getResource(CSS_FILE).toExternalForm());

			primaryStage.setTitle("Secure Pass - CSCE 5550 - UNT");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
