package com.unt.csce5550.jerin.securepass;

import com.unt.csce5550.jerin.securepass.utils.AppUtils;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EncryptionKeyConfirmBox {
	
	static String encryptionKey = "";
	
	public static String confirm(String title, String message) {
		encryptionKey = "";

		Stage window = new Stage();
		
		
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(250);
		
		Label label = new Label();
		label.setText(message);
		
		Label statusLabel = new Label();
		PasswordField encryptionKeyField = new PasswordField();
		PasswordField encryptionKeyConfirmField = new PasswordField();
		
		encryptionKeyField.setPromptText("Encryption Key");
		encryptionKeyConfirmField.setPromptText("Confirm Encryption Key");
		
		
		
		Button submitButton = new Button("Submit");
		submitButton.setOnAction(e -> {
			
			String key = encryptionKeyField.getText();
			String keyConfirm = encryptionKeyConfirmField.getText();
			
			if(!AppUtils.isEmpty(key) && !AppUtils.isEmpty(keyConfirm) && key.equals(keyConfirm)) {
				encryptionKey = encryptionKeyField.getText();
				if(AppUtils.isEmpty(encryptionKey)){
					statusLabel.setText("Encryption Key cannot be empty");
					return;
				}
				window.close();	
			}else {
				statusLabel.setText("Keys do not match");
				return;
			}
		});
		
		
		VBox vBox = new VBox(10);
		vBox.getChildren().addAll(label, encryptionKeyField, encryptionKeyConfirmField,  submitButton, statusLabel);
	    Insets labelInset = new Insets(5,10,5,10);
		VBox.setMargin(encryptionKeyField, labelInset);
		VBox.setMargin(encryptionKeyConfirmField, labelInset);
		vBox.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(vBox);
		window.setScene(scene);
		window.showAndWait();
		
		return encryptionKey;
		
	}

}
