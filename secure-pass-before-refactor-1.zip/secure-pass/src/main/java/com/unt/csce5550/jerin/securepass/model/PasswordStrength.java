package com.unt.csce5550.jerin.securepass.model;

public 	enum PasswordStrength {
	WEAK,
	MEDIUM,
	STRONG
}
