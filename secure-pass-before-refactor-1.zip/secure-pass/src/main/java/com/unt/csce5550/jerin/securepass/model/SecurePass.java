package com.unt.csce5550.jerin.securepass.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SecurePass {
	
	private List<User> users = new ArrayList<>();

	public SecurePass(List<User> users) {
		super();
		this.users = users;
	}

	public SecurePass() {
		super();
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}
	
	public void addUsers(List<User> usersList) {
		if(this.users==null) {
			this.users = new ArrayList<>();
		}
		this.users.addAll(usersList);
	}
	
	public void addUser(User user) {
		if(users==null) {
			users = new ArrayList<>();
		}
		users.add(user);
	}
	

	@Override
	public String toString() {
		return "SecurePass [users=" + users + "]";
	}
}