package com.unt.csce5550.jerin.securepass.service;

import java.util.Date;

import com.unt.csce5550.jerin.securepass.model.SecurePass;
import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;

public class UserService {
	
	public static User authenticateUser(String userId, String password) throws ApplicationException{
		System.out.println("authenticateUser called with userId: "+userId+"; password: "+password);
		User user = getUser(userId);
		
		if(user != null && (user.getFailedPasswordAttempts() >=3  && AppUtils.getDateDiffInMinutes(user.getLastFailedAttempt(), new Date()) <= 60 )) {
			throw new ApplicationException("Too many invalid attempts.  Try after 1 hour!");
		}
		
		if(user != null && user.getPassword().equals(password)) {
			//Successful Authentication.  Reset last failed attempts.
			resetFailedLoginAttempt(userId);
			return getUser(userId);
		}
		
		incrementFailedLoginAttempt(userId);
		throw new ApplicationException("Authentication Failed.");
	}
	
	public static User authenticateUserPassPhrase(String userId, String passPhrase) {
		System.out.println("authenticateUserPassPhrase called with userId: "+userId+"; passPhrase: "+passPhrase);
		User user = getUser(userId);
		if(user != null && user.getPassPhrase().equals(passPhrase)) {
			return user;
		}
		return null;
	}
	
	public static boolean addUser(User user) throws ApplicationException{
		System.out.println("addUser called with user: "+user);
		User existingUser = getUser(user.getUserId());
		if(existingUser!=null) {
			throw new ApplicationException("User Already Exists"+user);
		}
		SecurePass sp = XmlDataService.readXML();
		sp.addUser(user);
		
		XmlDataService.writeXML(sp);
		
		return true;

	}
	
	public static void updateUser(User newUser) throws ApplicationException {
		System.out.println("updateUser called with newUser: "+newUser);
		User existingUser = getUser(newUser.getUserId());
		if(existingUser==null) {
			throw new ApplicationException("User Does not exist: "+newUser);
		}
		SecurePass sp = XmlDataService.readXML();
		for(User user: sp.getUsers()) {
			if(user.getUserId().equalsIgnoreCase(newUser.getUserId()) ) {
				user.setFirstName(newUser.getFirstName());
				user.setLastName(newUser.getLastName());
				user.setPassword(newUser.getPassword());
				user.setPassPhrase(newUser.getPassPhrase());
				user.setFailedPasswordAttempts(newUser.getFailedPasswordAttempts());
				user.setLastFailedAttempt(newUser.getLastFailedAttempt());
			}
		}
		
		XmlDataService.writeXML(sp);
	}
	
	public static User getUser(String userId) {
		System.out.println("getUser called with userId: "+userId);
		SecurePass sp = XmlDataService.readXML();
		for(User user: sp.getUsers()) {
			if(user.getUserId().equalsIgnoreCase(userId) ) {
				return user;
			}
		}
		return null;
	}
	
	public boolean isExistingUser(User user) {
		System.out.println("isExistingUser called with user: "+user);
		return isExistingUser(user.getUserId());
	}
	
	public boolean isExistingUser(String userID) {
		System.out.println("isExistingUser called with userID: "+userID);
		User existingUser = getUser(userID);
		if(existingUser!=null) {
			return true;
		}else {
			return false;
		}
	}
	
	
	public static boolean incrementFailedLoginAttempt(String userId) throws ApplicationException {
		User user = getUser(userId);
		if(user == null) {
			return false;
		}
		
		Integer failedPasswordAttempts = user.getFailedPasswordAttempts();
		failedPasswordAttempts++;
		user.setFailedPasswordAttempts(failedPasswordAttempts);
		user.setLastFailedAttempt(new Date());
		
		updateUser(user);
		
		return false;
	}
	
	
	public static boolean resetFailedLoginAttempt(String userId) throws ApplicationException {
		User user = getUser(userId);
		if(user == null) {
			return false;
		}
		
		user.setFailedPasswordAttempts(0);
		user.setLastFailedAttempt(null);
		
		updateUser(user);
		
		return false;
	}

}
