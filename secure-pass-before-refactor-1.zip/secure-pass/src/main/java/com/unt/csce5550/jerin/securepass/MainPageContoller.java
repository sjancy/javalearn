package com.unt.csce5550.jerin.securepass;

import java.io.IOException;
import java.util.Iterator;

import com.unt.csce5550.jerin.securepass.model.Site;
import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.service.EncryptionService;
import com.unt.csce5550.jerin.securepass.service.SiteService;
import com.unt.csce5550.jerin.securepass.service.UserService;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;
import com.unt.csce5550.jerin.securepass.utils.ApplicationException;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image ;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;


public class MainPageContoller {
	
	@FXML 
	private Label welcomeLabel;
	
	@FXML 
	private Label testLabel;
	
	@FXML 
	private GridPane gridPane;
	
	@FXML
	private Label statusLabel;



	
	public void initializePage(User user) {
		//welcomeLabel = new Label();
		System.out.println("initializePage called with user: "+user);
		welcomeLabel.setText("Welcome "+user.getFirstName()+" "+user.getLastName());
		
		/*Button button = new Button("Button");
		GridPane.setRowIndex(button, 0);
		GridPane.setColumnIndex(button, 1);
		
		// or convenience methods set more than one constraint at once...
		Label label = new Label("Test");
		GridPane.setConstraints(label, 2, 0); // column=2 row=0
		
		// don't forget to add children to gridpane
		gridPane.getChildren().addAll(button, label);*/
	    
		//gridPane.getChildren().clear();
		//gridPane.getChildren().remove(0);
		//gridPane.setGridLinesVisible(true);

	    int rowNum = 1;
	    for(Site site: user.getSites()) {
		    Label siteLabel = new Label(site.getSite());
		    Label userId = new Label(site.getUserId());
		    Label pass = new Label("******"); //new Label(c.getPassword());
		    
		    Insets labelInset = new Insets(5,0,0,10); //Only top 5 and left 10 padding
		    siteLabel.setPadding(labelInset);
		    userId.setPadding(labelInset);
		    pass.setPadding(labelInset);
		    
		    
		    
		    RowConstraints r = new RowConstraints(30);
		    gridPane.getRowConstraints().add(r);
		    
		    gridPane.add(siteLabel, 0, rowNum);
		    gridPane.add(userId, 1, rowNum);
		    gridPane.add(pass, 2, rowNum);
		    
		    int imageWidth = 20;
		    int imageHeight = 20;
		    
		    
		    HBox hbox = new HBox();
		    Insets inset = new Insets(5,0,0,10); //Only top 5 and left 10 padding
			hbox.setPadding(inset);
			hbox.setSpacing(10);
			
			
			//Image image = new Image(getClass().getResourceAsStream("images/view.png"));
			Image image = new Image("images/view.png");
		    ImageView imageView = new ImageView(image);
		    imageView.setFitWidth(imageWidth);
		    imageView.setFitHeight(imageHeight);
			Button button = new Button("", imageView);
			button.setPadding(Insets.EMPTY);
			button.setOnAction(getViewButtonEventHandler());
			button.setTooltip(new Tooltip("View"));
			button.setUserData(site);
			
		    hbox.getChildren().add(button);

			
		    
			/*Image viewImage = new Image("images/view.png");
			ImageView viewImageView = new ImageView(viewImage);
			viewImageView.setFitWidth(imageWidth);
			viewImageView.setFitHeight(imageHeight);
			viewImageView.addEventHandler(MouseEvent.MOUSE_CLICKED, getEventHandler());
			hbox.getChildren().add(viewImageView);
			//gridPane.add(viewImageView, 3, rowNum);*/
					    
		    Image editImage = new Image("images/edit.png");
		    ImageView editImageView = new ImageView(editImage);
		    editImageView.setFitWidth(imageWidth);
		    editImageView.setFitHeight(imageHeight);
			Button editButton = new Button("", editImageView);
			editButton.setPadding(Insets.EMPTY);
			editButton.setOnAction(getModifyButtonEventHandler());
			editButton.setTooltip(new Tooltip("Edit"));
			editButton.setUserData(site);
		    hbox.getChildren().add(editButton);
		    

		    Image deleteImage = new Image("images/delete-3.png");
		    ImageView deleteImageView = new ImageView(deleteImage);
		    deleteImageView.setFitWidth(imageWidth);
		    deleteImageView.setFitHeight(imageHeight);
			Button deleteButton = new Button("", deleteImageView);
			deleteButton.setPadding(Insets.EMPTY);
			deleteButton.setOnAction(getDeleteButtonEventHandler());
			deleteButton.setTooltip(new Tooltip("Delete"));
			deleteButton.setUserData(site);
		    hbox.getChildren().add(deleteButton);

		    
		    hbox.getChildren().add(deleteImageView);

		    gridPane.add(hbox, 3, rowNum);

		    rowNum++;
	    }
	    
	}
	
	/*private EventHandler<MouseEvent> getEventHandler() {
		
		EventHandler<MouseEvent> ev = new EventHandler<MouseEvent>() {
	
		     @Override
		     public void handle(MouseEvent event) {
		         System.out.println("Tile pressed ");
		         event.consume();
		         System.out.println("After Consume pressed ");
	
		 		try {
					Parent newViewParent = FXMLLoader.load(getClass().getResource("ViewCredsPage.fxml"));
			         System.out.println("newViewParent loaded ");
					Scene newScene = new Scene(newViewParent);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}*/
	
	
	private EventHandler<ActionEvent> getViewButtonEventHandler() {
		
		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

		     @Override
		     public void handle(ActionEvent event) {
		         System.out.println("View button pressed "+event);
		         
		         String encryptionKey = EncryptionKeyBox.confirm("Encryption Key", "Enter the encryption key");
		         
		         System.out.println("encryptionKey: "+encryptionKey);
		         if(AppUtils.isEmpty(encryptionKey)) {
		        	 return;
		         }
		         
		         System.out.println("Source: "+event.getSource());
		         Object obj = event.getSource();
		         Object userData =  ((Button) obj).getUserData() ;
		         Site site = (Site)userData;
		         
		         try {
					site = EncryptionService.decryptSitePasswords(site, encryptionKey);
				} catch (ApplicationException e1) {
					statusLabel.setText("Invalid Encryption Key");
					e1.printStackTrace();
					return;
				}
		         
		         System.out.println( ((Button) obj).getUserData() );
		         
		         

		         //event.consume();
		         System.out.println("After Consume pressed ");

		 		try {
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource("ViewCredsPage.fxml"));
					Parent newViewParent = loader.load();
					
					Scene newScene = new Scene(newViewParent);
					ViewCredsPageController newSceneController = loader.getController();
					newSceneController.populateScreen(site);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}
	
	
	private EventHandler<ActionEvent> getModifyButtonEventHandler() {
		
		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

		     @Override
		     public void handle(ActionEvent event) {
		         System.out.println("Modify button pressed "+event);

		         System.out.println("Source: "+event.getSource());
		         Object obj = event.getSource();
		         Object userData =  ((Button) obj).getUserData() ;
		         Site site = (Site)userData;
		         
		         
		         String encryptionKey = EncryptionKeyBox.confirm("Encryption Key", "Enter the encryption key");
		         
		         System.out.println("encryptionKey: "+encryptionKey);
		         if(AppUtils.isEmpty(encryptionKey)) {
		        	 return;
		         }
		         
		         try {
					site = EncryptionService.decryptSitePasswords(site, encryptionKey);
				} catch (ApplicationException e1) {
					statusLabel.setText("Invalid Encryption Key");
					e1.printStackTrace();
					return;
				}


		         //event.consume();
		         System.out.println("After Consume pressed ");

		 		try {
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource("ModifyCredsPage.fxml"));
					Parent newViewParent = loader.load();
					
					Scene newScene = new Scene(newViewParent);
					ModifyCredsPageController newSceneController = loader.getController();
					newSceneController.populateScreen(site, encryptionKey);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}
	
	
	private EventHandler<ActionEvent> getDeleteButtonEventHandler() {

		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				System.out.println("Delete button pressed " + event);
				System.out.println("Source: " + event.getSource());
				boolean confirmStatus = ConfirmationBox.confirm("Delete Confirm", "Are you sure?");
				if(!confirmStatus) {
					return;
				}
				Object obj = event.getSource();
				Object userData = ((Button) obj).getUserData();
				Site site = (Site) userData;

				try {
					String currentUserId = LoginController.getCurrentUser().getUserId();
					SiteService.deleteSite(currentUserId, site);
				} catch (ApplicationException e) {
					e.printStackTrace();
					statusLabel.setText("Delete Site Failed: "+e.getMessage());
					return;
				}
				
				//clearGridPane();
				
				reloadPage(event);
				//initializePage(LoginController.getCurrentUser());
			}
		};

		return ev;

	}
	
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			Parent newViewParent = FXMLLoader.load(getClass().getResource("Login.fxml"));
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void clearGridPane() {
		
		
		Iterator<Node> iterator = gridPane.getChildren().iterator();
		while(iterator.hasNext()) {
			//for (Node child : gridPane.getChildren()) {
			Node child = iterator.next();
		    Integer column = GridPane.getColumnIndex(child);
		    Integer row = GridPane.getRowIndex(child);
		    
		    //header
		    if(row!=null && row==0) {
		    	continue;
		    }
		    
		    if (column != null && row != null) {
				System.out.println(column+" - "+row+" - "+child);
				iterator.remove();
		    }
		}
		
		//return gridPaneNodes;
		
	}

	
	
	public void newSiteButtonClicked(ActionEvent event) {
		System.out.println("New Site Back Button Clicked ");
		
 		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("NewCredsPage.fxml"));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			NewCredsPageController newSceneController = loader.getController();
			newSceneController.populateScreen();
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void reloadPage(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader();
			//loader.setLocation(getClass().getResource("/fxml/MainPage.fxml"));
			loader.setLocation(getClass().getResource("MainPage.fxml"));
			Parent newViewParent = loader.load();
			
			
			//Parent newViewParent = FXMLLoader.load(getClass().getResource("NewScene.fxml"));
			Scene newScene = new Scene(newViewParent);

			User currentUser = LoginController.getCurrentUser();
			currentUser = UserService.getUser(currentUser.getUserId());

			MainPageContoller newSceneController = loader.getController();
			newSceneController.initializePage(currentUser);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void generatePasswordClicked(ActionEvent event) {
		System.out.println("generatePasswordClicked Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("GeneratePasswordPage.fxml"));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			//GeneratePasswordPageController newSceneController = loader.getController();
			//User user = UserService.getUser(LoginController.getCurrentUser().getUserId());
			//newSceneController.initializePage(user);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
}
