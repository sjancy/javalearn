package com.unt.csce5550.jerin.securepass.utils;

import javafx.scene.control.TextField;

public class AppUtils {
	public static boolean isEmpty(TextField tf) {
		
		if(tf!=null && !isEmpty(tf.getText())) {
			return false;
		}
		return true;
	}
	
	public static boolean isEmpty(String str) {
		if(str!=null && str.trim().length()>0) {
			return false;
		}
		return true;
	}
	
	public static String getText(TextField tf) {
		
		if(!isEmpty(tf)) {
			return tf.getText();
		}else {
			return null;
		}
		
	}

}
