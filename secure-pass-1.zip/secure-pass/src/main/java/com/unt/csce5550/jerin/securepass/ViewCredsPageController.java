package com.unt.csce5550.jerin.securepass;

import java.io.IOException;

import com.unt.csce5550.jerin.securepass.model.Attribute;
import com.unt.csce5550.jerin.securepass.model.Site;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;

public class ViewCredsPageController {

	@FXML 
	private Label siteNameLabel;
	
	@FXML 
	private GridPane attributesGridPane;
	
	
	public void populateScreen(Site site) {
		System.out.println("populateScreen called.  site: "+site);
		
		siteNameLabel.setText(site.getSite());
		
	    Label userLabel = new Label("User ID");
	    Label userId = new Label(site.getUserId());
	    
	    Label passLabel = new Label("Password");
	    Label pass = new Label(site.getPassword());
	    
	    Insets labelInset = new Insets(5,0,0,10); // top 5 and left 10 padding
	    userLabel.setPadding(labelInset);
	    userId.setPadding(labelInset);
	    passLabel.setPadding(labelInset);
	    pass.setPadding(labelInset);
	    
	    RowConstraints r = new RowConstraints(30);
	    attributesGridPane.getRowConstraints().add(r);
	    int rowNum = 1;

	    attributesGridPane.add(userLabel, 0, rowNum);
	    attributesGridPane.add(userId, 1, rowNum);
	    rowNum++;
	    
	    attributesGridPane.add(passLabel, 0, rowNum);
	    attributesGridPane.add(pass, 1, rowNum);
	    rowNum++;

	    for(Attribute attr: site.getAttributeList()) {
		    Label attrNameLabel = new Label(attr.getAttributeName());
		    attrNameLabel.setPadding(labelInset);
		    Label attrValueLabel = new Label(attr.getAttributeValue());
		    attrValueLabel.setPadding(labelInset);

		    attributesGridPane.add(attrNameLabel, 0, rowNum);
		    attributesGridPane.add(attrValueLabel, 1, rowNum);
		    rowNum++;
	    }
		
	}
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("MainPage.fxml"));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			MainPageContoller newSceneController = loader.getController();
			newSceneController.setLabelText("Jerin");
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void editButtonClicked(ActionEvent event) {
		System.out.println("Edit Button Clicked ");
		
		try {
			Parent newViewParent = FXMLLoader.load(getClass().getResource("Login.fxml"));
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
