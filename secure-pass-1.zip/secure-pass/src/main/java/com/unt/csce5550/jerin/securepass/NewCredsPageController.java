package com.unt.csce5550.jerin.securepass;

import java.io.IOException;

import com.unt.csce5550.jerin.securepass.model.Attribute;
import com.unt.csce5550.jerin.securepass.model.Site;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;

public class NewCredsPageController {
	
	@FXML 
	private TextField siteNameTextField;

	@FXML 
	private GridPane attributesGridPane;
	
	
	public void populateScreen() {
		System.out.println("NewCredsPageController: populateScreen called.  site: ");
		
		//siteNameLabel.setText(site.getSite());
		
	    Label userLabel = new Label("User ID");
	    TextField userId = new TextField();
	    
	    Label passLabel = new Label("Password");
	    TextField pass = new TextField();
	    
	    Insets labelInset = new Insets(5,0,0,10); // top 5 and left 10 padding
	    userLabel.setPadding(labelInset);
	    userId.setPadding(labelInset);
	    passLabel.setPadding(labelInset);
	    pass.setPadding(labelInset);
	    
	    RowConstraints r = new RowConstraints(30);
	    attributesGridPane.getRowConstraints().add(r);
	    //attributesGridPane.setGridLinesVisible(false);
	    
	    //Rownum 0 is header
	    
	    //Rownum 1
	    int rowNum = 1;
	    attributesGridPane.add(userLabel, 0, rowNum,1,1);
	    attributesGridPane.add(userId, 1, rowNum,1,1);
	    rowNum++;
	    
	    //Rownum 2
	    attributesGridPane.add(passLabel, 0, rowNum,1,1);
	    attributesGridPane.add(pass, 1, rowNum,1,1);
	    rowNum++;
	    
		/*
		//Rownum 3
		Insets pbInset = new Insets(5,10,5,10); // top 5 and left 10 padding
		ProgressBar pb = new ProgressBar(0.7);
		pb.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
		pb.setPadding(pbInset);
		//GridPane.setColumnSpan(pb, GridPane.REMAINING);
		attributesGridPane.add(pb, 0, rowNum, 2, 1);
		rowNum++;
		
		//Rownum 4
		Label psStrengthLbl = new Label("Password Strength: Weak");
		psStrengthLbl.setPadding(pbInset);
		attributesGridPane.add(psStrengthLbl, 0, rowNum, 2, 1);
		rowNum++;*/



		for(;rowNum<13;rowNum++) {
			TextField attrNameTF = new TextField();
		    attrNameTF.setPadding(labelInset);
		    TextField attrValueTF = new TextField();
		    attrValueTF.setPadding(labelInset);
		
		    attributesGridPane.add(attrNameTF, 0, rowNum);
		    attributesGridPane.add(attrValueTF, 1, rowNum);
		}
		
	}
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("MainPage.fxml"));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			MainPageContoller newSceneController = loader.getController();
			newSceneController.setLabelText("Jerin");
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void saveButtonClicked(ActionEvent event) {
		System.out.println("Save Button Clicked ");
		Node[][] gridNodes = gridPaneNodesAsArray();
		
		Site site = new Site();
		
		//Row 0 is header
		
		//Row 1 is User
		TextField userIdTextField = (TextField)gridNodes[1][1];
		String userId = (userIdTextField!=null)?userIdTextField.getText():null;
		
		//Row 1 is Password
		TextField passwdTextField = (TextField)gridNodes[1][2];
		String password = (passwdTextField!=null)?passwdTextField.getText():null;
		
		
		System.out.println("User ID: "+userId);
		System.out.println("Password: "+password);
		
		site.setSite(siteNameTextField.getText());
		site.setUserId(userId);
		site.setPassword(password);
		
		System.out.println("Length: "+gridNodes[0].length);
		
		for(int i=3; i<gridNodes[0].length; i++) {
			if(!( gridNodes[0][i] instanceof TextField)) {
				continue;
			}
			TextField attrName = (TextField)gridNodes[0][i];
			TextField attrValue = (TextField)gridNodes[1][i];
			
			
			if(!isEmpty(attrName) && !isEmpty(attrValue) ) {
				System.out.println(i+": "+attrName.getText()+" - "+attrValue.getText());
				Attribute attr = new Attribute(attrName.getText(), attrValue.getText());
				site.addAttribute(attr);
			}
		}
		System.out.println("New Site: "+site);
		
		
	}
	
	public static boolean isEmpty(TextField tf) {
		
		if(tf!=null && !isEmpty(tf.getText())) {
			return false;
		}
		return true;
	}
	
	public static boolean isEmpty(String str) {
		if(str!=null && str.trim().length()>0) {
			return false;
		}
		return true;
	}
	
	public Node[][] gridPaneNodesAsArray() {
		
		Node [][] gridPaneNodes = new Node[3][15] ;
		
		for (Node child : attributesGridPane.getChildren()) {
		    Integer column = GridPane.getColumnIndex(child);
		    Integer row = GridPane.getRowIndex(child);
		    if (column != null && row != null) {
				System.out.println(column+" - "+row+" - "+child);
		        gridPaneNodes[column][row] = child ;
		    }
		}
		
		return gridPaneNodes;
		
	}
	
	


}
