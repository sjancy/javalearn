package com.unt.csce5550.jerin.securepass;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.unt.csce5550.jerin.securepass.model.Attribute;
import com.unt.csce5550.jerin.securepass.model.Site;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;
import javafx.scene.image.Image ;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;


public class MainPageContoller {
	
	@FXML 
	private Label welcomeLabel;
	
	@FXML 
	private Label testLabel;
	
	@FXML 
	private GridPane gridPane;



	
	public void setLabelText(String name) {
		//welcomeLabel = new Label();
		welcomeLabel.setText("Welcome "+name);
		
		
		/*Button button = new Button("Button");
		GridPane.setRowIndex(button, 0);
		GridPane.setColumnIndex(button, 1);
		
		// or convenience methods set more than one constraint at once...
		Label label = new Label("Test");
		GridPane.setConstraints(label, 2, 0); // column=2 row=0
		
		// don't forget to add children to gridpane
		gridPane.getChildren().addAll(button, label);*/
	    
	    
	    int rowNum = 1;
	    for(Site site: getTestSites()) {
		    Label siteLabel = new Label(site.getSite());
		    Label userId = new Label(site.getUserId());
		    Label pass = new Label("******"); //new Label(c.getPassword());
		    
		    Insets labelInset = new Insets(5,0,0,10); //Only top 5 and left 10 padding
		    siteLabel.setPadding(labelInset);
		    userId.setPadding(labelInset);
		    pass.setPadding(labelInset);
		    
		    RowConstraints r = new RowConstraints(30);
		    gridPane.getRowConstraints().add(r);

		    gridPane.add(siteLabel, 0, rowNum);
		    gridPane.add(userId, 1, rowNum);
		    gridPane.add(pass, 2, rowNum);
		    
		    int imageWidth = 20;
		    int imageHeight = 20;
		    
		    
		    HBox hbox = new HBox();
		    Insets inset = new Insets(5,0,0,10); //Only top 5 and left 10 padding
			hbox.setPadding(inset);
			hbox.setSpacing(5);
			
			
			//Image image = new Image(getClass().getResourceAsStream("images/view.png"));
			Image image = new Image("images/view.png");
		    ImageView imageView = new ImageView(image);
		    imageView.setFitWidth(imageWidth);
		    imageView.setFitHeight(imageHeight);
			Button button = new Button("", imageView);
			button.setPadding(Insets.EMPTY);
			//button.setPadding(new Insets(-5,-5,-5,-5));
			//button.addEventHandler(MouseEvent.MOUSE_CLICKED, getEventHandler());
			button.setOnAction(getViewButtonEventHandler());
			button.setUserData(site);
			
		    hbox.getChildren().add(button);

			
		    
			/*Image viewImage = new Image("images/view.png");
			ImageView viewImageView = new ImageView(viewImage);
			viewImageView.setFitWidth(imageWidth);
			viewImageView.setFitHeight(imageHeight);
			viewImageView.addEventHandler(MouseEvent.MOUSE_CLICKED, getEventHandler());
			hbox.getChildren().add(viewImageView);
			//gridPane.add(viewImageView, 3, rowNum);*/
					    
		    Image editImage = new Image("images/edit.png");
		    ImageView editImageView = new ImageView(editImage);
		    editImageView.setFitWidth(imageWidth);
		    editImageView.setFitHeight(imageHeight);
			Button editButton = new Button("", editImageView);
			editButton.setPadding(Insets.EMPTY);
			editButton.setOnAction(getModifyButtonEventHandler());
			editButton.setUserData(site);
		    hbox.getChildren().add(editButton);
		    

		    Image deleteImage = new Image("images/delete-3.png");
		    ImageView deleteImageView = new ImageView(deleteImage);
		    deleteImageView.setFitWidth(imageWidth);
		    deleteImageView.setFitHeight(imageHeight);
		    hbox.getChildren().add(deleteImageView);

		    gridPane.add(hbox, 3, rowNum);

		    rowNum++;
	    }
	    
	}
	
	/*private EventHandler<MouseEvent> getEventHandler() {
		
		EventHandler<MouseEvent> ev = new EventHandler<MouseEvent>() {
	
		     @Override
		     public void handle(MouseEvent event) {
		         System.out.println("Tile pressed ");
		         event.consume();
		         System.out.println("After Consume pressed ");
	
		 		try {
					Parent newViewParent = FXMLLoader.load(getClass().getResource("ViewCredsPage.fxml"));
			         System.out.println("newViewParent loaded ");
					Scene newScene = new Scene(newViewParent);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}*/
	
	
	private EventHandler<ActionEvent> getViewButtonEventHandler() {
		
		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

		     @Override
		     public void handle(ActionEvent event) {
		         System.out.println("View button pressed "+event);
		         System.out.println("Source: "+event.getSource());
		         Object obj = event.getSource();
		         Object userData =  ((Button) obj).getUserData() ;
		         Site site = (Site)userData;
		         
		         System.out.println( ((Button) obj).getUserData() );

		         //event.consume();
		         System.out.println("After Consume pressed ");

		 		try {
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource("ViewCredsPage.fxml"));
					Parent newViewParent = loader.load();
					
					Scene newScene = new Scene(newViewParent);
					ViewCredsPageController newSceneController = loader.getController();
					newSceneController.populateScreen(site);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}
	
	
	private EventHandler<ActionEvent> getModifyButtonEventHandler() {
		
		EventHandler<ActionEvent> ev = new EventHandler<ActionEvent>() {

		     @Override
		     public void handle(ActionEvent event) {
		         System.out.println("Modify button pressed "+event);
		         System.out.println("Source: "+event.getSource());
		         Object obj = event.getSource();
		         Object userData =  ((Button) obj).getUserData() ;
		         Site site = (Site)userData;
		         
		         System.out.println( ((Button) obj).getUserData() );

		         //event.consume();
		         System.out.println("After Consume pressed ");

		 		try {
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource("ModifyCredsPage.fxml"));
					Parent newViewParent = loader.load();
					
					Scene newScene = new Scene(newViewParent);
					ModifyCredsPageController newSceneController = loader.getController();
					newSceneController.populateScreen(site);
					
					Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
					window.setScene(newScene);
					window.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
		     }
		};
		
		return ev;
		
	}
	
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			Parent newViewParent = FXMLLoader.load(getClass().getResource("Login.fxml"));
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void newSiteButtonClicked(ActionEvent event) {
		System.out.println("New Site Back Button Clicked ");
		
 		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("NewCredsPage.fxml"));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			NewCredsPageController newSceneController = loader.getController();
			newSceneController.populateScreen();
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private List<Site> getTestSites(){
		
		List<Site> siteList = new ArrayList<>();
		siteList.add(new Site("Amazon", "amzUser", "amzPass"));
		siteList.add(new Site("Yahoo", "yahUser", "yahPass"));
		siteList.add(new Site("Gmail", "gmlUser", "gmlPass"));
		siteList.add(new Site("Outlook", "outUser", "outPass"));
		siteList.add(new Site("BOA", "boaUser", "boaPass"));
		return addAttributes(siteList);
		
	}
	
	
	private List<Site> addAttributes(List<Site> siteList){
		
		for(Site site: siteList) {
			site.getAttributeList().add(new Attribute("ATM PIN", "1122"));
			site.getAttributeList().add(new Attribute("Customer Care No", "888-232-8757"));
			site.getAttributeList().add(new Attribute("Pass Phrase", "Spell it out!"));
		}

		return siteList;
	}
}
