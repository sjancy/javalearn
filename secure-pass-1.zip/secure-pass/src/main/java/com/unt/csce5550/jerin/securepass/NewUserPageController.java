package com.unt.csce5550.jerin.securepass;

import java.io.IOException;

import com.unt.csce5550.jerin.securepass.model.User;
import com.unt.csce5550.jerin.securepass.utils.AppUtils;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class NewUserPageController {
	
	@FXML 
	private TextField siteNameTextField;

	@FXML 
	private TextField firstNameField;
	
	@FXML 
	private TextField lastNameField;
	
	@FXML 
	private TextField userIdField;
	
	@FXML 
	private PasswordField passwordField;
	
	@FXML 
	private PasswordField confirmPasswordField;
	
	@FXML 
	private PasswordField passPhraseField;
	
	@FXML 
	private PasswordField confirmPassPhraseField;

	@FXML 
	private GridPane attributesGridPane;
	
	@FXML 
	private Label statusLabel;
	
	@FXML 
	private ProgressBar passwordStrengthBar;

	@FXML 
	private Label passwordStrengthLabel;
	
	
	public void goBackButtonClicked(ActionEvent event) {
		System.out.println("Go Back Button Clicked ");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("Login.fxml"));
			Parent newViewParent = loader.load();
			
			Scene newScene = new Scene(newViewParent);
			//LoginController newSceneController = loader.getController();
			//newSceneController.setLabelText("Jerin");
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void saveButtonClicked(ActionEvent event) {
		System.out.println("Save Button Clicked ");
		
		if(!validate()) {
			System.out.println("Validation Failed!");
			return;
		}
		
		String firstName = AppUtils.getText(firstNameField);
		String lastName = AppUtils.getText(lastNameField);
		String userId = AppUtils.getText(userIdField);
		String password = AppUtils.getText(passwordField);
		String passPhrase = AppUtils.getText(passPhraseField);
		
		User user = new User(firstName, lastName, userId,  password, passPhrase);
		
		statusLabel.setText("User Created Successfully!");
		

		System.out.println("New User: "+user);
		
		
	}
	
	

	public boolean validate() {
		String firstName = AppUtils.getText(firstNameField);
		String lastName = AppUtils.getText(lastNameField);
		String userId = AppUtils.getText(userIdField);
		String password = AppUtils.getText(passwordField);
		String confirmPassword = AppUtils.getText(confirmPasswordField);
		String passPhrase = AppUtils.getText(passPhraseField);
		String confirmPassPhrase = AppUtils.getText(confirmPassPhraseField);
		
		
		if(AppUtils.isEmpty(firstName)) {
			statusLabel.setText("First Name cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(lastName)) {
			statusLabel.setText("Last Name cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(userId)) {
			statusLabel.setText("User ID Name cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(password)) {
			statusLabel.setText("Password cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(confirmPassword)) {
			statusLabel.setText("Confirm Password cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(passPhrase)) {
			statusLabel.setText("Pass Phrase cannot be empty");
			return false;
		}
		if(AppUtils.isEmpty(confirmPassPhrase)) {
			statusLabel.setText("Confirm Pass Phrase cannot be empty");
			return false;
		}
		
		if(password.equals(confirmPassword)) {
			statusLabel.setText("Passwords do not match!");
			return false;
		}
		
		if(passPhrase.equals(confirmPassPhrase)) {
			statusLabel.setText("Pass Phrases do not match!");
			return false;
		}
		
		return true;

	}
	
	


}
