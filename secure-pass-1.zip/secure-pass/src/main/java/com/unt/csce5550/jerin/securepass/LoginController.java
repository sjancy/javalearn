package com.unt.csce5550.jerin.securepass;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LoginController {
	
	public void loginButtonClicked(ActionEvent event) {
		System.out.println("User Logged In");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			//loader.setLocation(getClass().getResource("/fxml/MainPage.fxml"));
			loader.setLocation(getClass().getResource("MainPage.fxml"));
			Parent newViewParent = loader.load();
			
			
			//Parent newViewParent = FXMLLoader.load(getClass().getResource("NewScene.fxml"));
			Scene newScene = new Scene(newViewParent);
			
			MainPageContoller newSceneController = loader.getController();
			newSceneController.setLabelText("Jerin");
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void newUserLinkClicked(ActionEvent event) {
		System.out.println("New User Link Clicked");
		
		try {
			Parent newViewParent = FXMLLoader.load(getClass().getResource("NewUserPage.fxml"));
			Scene newScene = new Scene(newViewParent);
			
			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
	public void forgotPasswordLinkClicked(ActionEvent event) {
		System.out.println("Forgot Password Link Clicked");
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("ResetPasswordPage.fxml"));
			Parent newViewParent = loader.load();

			Scene newScene = new Scene(newViewParent);
			ResetPasswordController newSceneController = loader.getController();
			newSceneController.initScreen();
			

			Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
			window.setScene(newScene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
}
